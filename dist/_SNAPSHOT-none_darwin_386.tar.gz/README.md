TODO:
- not tests
- bad struct
- implementation logs
